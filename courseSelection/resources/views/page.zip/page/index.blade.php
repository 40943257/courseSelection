﻿@extends('page.layout.master')

@section('content')
    
@endsection